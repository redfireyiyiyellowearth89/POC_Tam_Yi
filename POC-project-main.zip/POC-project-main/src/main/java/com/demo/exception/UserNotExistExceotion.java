package com.demo.exception;

public class UserNotExistExceotion extends RuntimeException {
	public UserNotExistExceotion(String message) {
		super(message);
	}
}
